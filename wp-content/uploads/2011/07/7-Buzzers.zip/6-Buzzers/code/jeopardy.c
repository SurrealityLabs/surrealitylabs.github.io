#pragma bit P1Btn @ PORTB.0
#pragma bit P2Btn @ PORTB.1
#pragma bit P3Btn @ PORTB.2
#pragma bit P4Btn @ PORTB.3

#pragma bit P1LED @ PORTB.4
#pragma bit P2LED @ PORTB.5
#pragma bit P3LED @ PORTB.6
#pragma bit P4LED @ PORTB.7

#pragma bit BUZZER @ PORTA.1

#pragma bit READYLED @ PORTA.0

void delay_halfsec( void )
// Delays a multiple of 1 milliseconds at 4 MHz
// using the TMR0 timer
{
    char d1, d2, d3;

	#asm
Delay
	movlw	0x1c
	movwf	d1
Delay_00
	movlw	0x2e
	movwf	d2
Delay_01
	decfsz	d2, f
	goto 	Delay_01
	decfsz	d1, f
	goto	Delay_00

	movlw	0x06
	movwf	d1
Delay_10
	decfsz	d1, f
	goto	Delay_10
	#endasm
}

void main(void)
{
	CMCON = 7;
    
    TRISA = 0;
   	TRISB = 0b.0000.1111;
    PORTA = 0;
   	PORTB = 0;
	ANSEL = 0;
    while(1)
	{
	    READYLED = 1;
    
    	while((P1Btn == 0) && (P2Btn == 0) && (P3Btn == 0) && (P4Btn == 0)) nop();
    
	    if(P1Btn) P1LED=1;
    	else if(P2Btn) P2LED=1;
	    else if(P3Btn) P3LED=1;
    	else P4LED=1;
    
	    READYLED = 0;
    
    	BUZZER=1;
	    delay_halfsec();
    	BUZZER=0;
		PORTA=0;
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
	    delay_halfsec();
		PORTB = 0;
		READYLED = 1;
	};
}
