/*
 *  CVDTouch.cpp
 */

#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

#include "CVDTouch.h"

void CVDTouch_start(void) {
    // configure pins as analog
    analogRead(0);
    analogRead(1);
}

int CVDTouch_read(void) {
    // read from the reference channel
    analogRead(0);
    // read from the touch channel
    return analogRead(1);
}