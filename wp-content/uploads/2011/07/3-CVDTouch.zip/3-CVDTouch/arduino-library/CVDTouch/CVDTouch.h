/*
 *  CVDTouch.h
 */

#ifndef _CVDTouch_h_
#define _CVDTouch_h_

void CVDTouch_start(void);
int CVDTouch_read(void);

#endif
