This project is based on the USBTinyISP made by ladyada and Adafruit Industries. This version is meant for a single-sided circuit board.

For more information on this project, please visit http://www.ladyada.net/make/usbtinyisp/