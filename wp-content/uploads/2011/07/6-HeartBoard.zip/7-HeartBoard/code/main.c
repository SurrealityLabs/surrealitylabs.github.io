#include <htc.h>

#define ON 1
#define OFF 0

void LED(int led,char onOff);
int follow();
int inversefollow();
int run();
int heart();
int flash();
int everyother();

int checkSwich();
int delayTimer(int delay);
void offAll();

void main(void)
	{

	char i,j,k;
	int state=1;
	TRISA=0x00;
	TRISB=0b10000000;
	TRISC=0x00;
	PORTA=0x00;
	PORTB=0x00;
	PORTC=0x00;
	
		PORTA=0x0F;
		PORTB=0xFF;
		PORTC=0xFF;
		_delay(100000);
		
	
		PORTA=0x00;
		PORTB=0x00;
		PORTC=0x00;

	while(1)
	{	
		switch(state)
		{
			case 1:
				state+=everyother();
				break;
			
			case 2:
				state+=follow();
				break;
			
			case 3:
				state+=run();
				break;
			case 4:
				state+=heart();
				break;
			case 5:
				state+=flash();
				break;
			case 6:
				state+=inversefollow();
				break;
			default:
				state=1;
		
		}

	}
}



int follow()
{
	
	char i=0,j=1,k=2,l=3;



	for (i=1;i<19;i++)
	{
		j++;
		k++;
		l++;
		if (j>18)
		{
			j=1;
		}
		if (k>18)
		{
			k=1;
		}
		if (l>18)
			l=1;
		{
		}
		LED(i,ON);
		LED(j,ON);
		LED(k,ON);
		LED(l,ON);
		if(delayTimer(50))
		{
			return(1);
		}
		
		LED(i,OFF);
	}
	return(0);
}

int inversefollow()
{
	
	char i=0,j=1,k=2,l=3;
	PORTA=0x0F;
	PORTB=0xFF;
	PORTC=0xFF;


	for (i=1;i<19;i++)
	{
		j++;
		k++;
		l++;
		if (j>18)
		{
			j=1;
		}
		if (k>18)
		{
			k=1;
		}
		if (l>18)
			l=1;
		{
		}
		LED(i,OFF);
		LED(j,OFF);
		LED(k,OFF);
		LED(l,OFF);
		if(delayTimer(50))
		{
			return(1);
		}
		
		LED(i,ON);
	}
	return(0);
}



int run()
{
	char i;


	for (i=0;i<19;i++)
	{
		LED(i,ON);
		if(delayTimer(15))
		{
			return(1);
		}
		
	}
	
	for (i=0;i<19;i++)
	{
		LED(i,OFF);
		if(delayTimer(15))
		{
			return(1);
		}
	
	}
	return(0);
}

int heart()
{
	int i;
	char r;
	
	_delay(10000);

	r=13;

	
	//Turn On
	for (i=0;i<10;i++)
	{
		
		LED((r),ON);
		LED((i+13),ON);
		r--;
		if(delayTimer(50))
		{
			return(1);
		}
	}
	
	r=13;
	
	//Turn Off
	for (i=0;i<10;i++)
	{
		LED(13+i,OFF);
		LED(r,OFF);
		r--;
		if(delayTimer(50))
		{
			return(1);
		}
	}
	
	return (0);

}

		

		
	

int flash()
{
	PORTA=0x0F;
	PORTB=0xFF;
	PORTC=0xFF;
	
	if(delayTimer(200))
	{
		return(1);
	}
	
	PORTA=0x00;
	PORTB=0x00;
	PORTC=0x00;
	if(delayTimer(200))
	{
		return(1);
	}
	return(0);

}
	
int everyother()
{
	char i;
	for (i=1;i<19;i+=2)
	{
		LED(i,ON);
	}
	
	for (i=2;i<19;i+=2)
	{
		LED(i,OFF);
	}
	
	if(delayTimer(50))
		{
			return(1);
		}
	for (i=1;i<19;i+=2)
	{
		LED(i,OFF);
	}
	
	for (i=2;i<19;i+=2)
	{
		LED(i,ON);
	}
	if(delayTimer(50))
	{
		return(1);
	}
	return (0);
}	



int checkSwich()
{
	if (RB7==0)
	{
		return(1);			
	}else{
		return(0);
	}
}

int delayTimer(int delay)
{
	int i=0;
	for (i=0;i<delay;i++)
		{

			_delay(100);
			if (checkSwich())
			{
				_delay(100);
				if (checkSwich())
				{
					_delay(10000);
					offAll();
					return(1);
				}
			}
	}
	return(0);
}



void offAll()
{
	int i;
	for (i=0;i<19;i++)
	{
		LED(i,OFF);
	}
}
		


void LED(int led,char onOff)
	{
	
	while(led<0)
	{
		led+=18;
	}


	while(led>18)
	{
		led-=18;
	}


	switch(led)
		{
//PORTA
		case 1:
			PORTA= PORTA&0b11111110;
			PORTA= PORTA|(0x01*onOff);

			break;
		case 2:
			PORTA= PORTA&0b11111101;
			PORTA= PORTA|(0x02*onOff);
			break;
		case 3:
			PORTA= PORTA&0b11111011;
			PORTA= PORTA|(0x04*onOff);
			break;
		case 4:
			PORTA= PORTA&0b11110111;
			PORTA= PORTA|(0x08*onOff);
			break;
		case 5:
			PORTB&=0b11111110;
			PORTB |=(0x01*onOff);
			break;
		case 6:
			PORTB&=0b11111101;
			PORTB|=(0x02*onOff);
			break;
		case 7:
			PORTB&=0b11111011;
			PORTB|=(0x04*onOff);
			break;
		case 8:
			PORTB&=0b11110111;
			PORTB|=(0x08*onOff);
			break;
		case 9:
			PORTB&=0b11101111;
			PORTB|=(0x10*onOff);
			break;
		case 10:
			PORTB&=0b11011111;
			PORTB|=(0x20*onOff);
			break;
	//Implimentation Change
	/*
		case 11:
			PORTB&=0b10111111;
			PORTB|=(0x40&onOff);
			break;
		case 12:
			PORTB&=0b01111111;
			PORTB|=(0x80&onOff);
			break;
	*/
//PORTC
		case 11:
			PORTC&=0b11111110;
			PORTC|=(0x01*onOff);
			break;
		case 12:
			PORTC&=0b11111101;
			PORTC|=(0x02*onOff);
			break;
		case 13:
			PORTC&=0b11111011;
			PORTC|=(0x04*onOff);
			break;
		case 14:
			PORTC&=0b11110111;
			PORTC|=(0x08*onOff);
			break;
		case 15:
			PORTC&=0b11101111;
			PORTC|=(0x10*onOff);
			break;
		case 16:
			PORTC&=0b11011111;
			PORTC|=(0x20*onOff);
			break;
		case 17:
			PORTC&=0b10111111;
			PORTC|=(0x40*onOff);
			break;
		case 18:
			PORTC&=0b01111111;
			PORTC|=(0x80*onOff);
			break;
		default:
			break;
		}
	}