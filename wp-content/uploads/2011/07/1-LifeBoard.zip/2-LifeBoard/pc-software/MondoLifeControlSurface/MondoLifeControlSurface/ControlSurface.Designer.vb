﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmControlSurface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rdoStopped = New System.Windows.Forms.RadioButton
        Me.rdoRunning = New System.Windows.Forms.RadioButton
        Me.btnToggleState = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rdoQuad4 = New System.Windows.Forms.RadioButton
        Me.rdoQuad3 = New System.Windows.Forms.RadioButton
        Me.rdoQuad2 = New System.Windows.Forms.RadioButton
        Me.rdoQuad1 = New System.Windows.Forms.RadioButton
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.rdoState8 = New System.Windows.Forms.RadioButton
        Me.rdoState7 = New System.Windows.Forms.RadioButton
        Me.rdoState6 = New System.Windows.Forms.RadioButton
        Me.rdoState5 = New System.Windows.Forms.RadioButton
        Me.rdoState4 = New System.Windows.Forms.RadioButton
        Me.rdoState3 = New System.Windows.Forms.RadioButton
        Me.rdoState2 = New System.Windows.Forms.RadioButton
        Me.rdoState1 = New System.Windows.Forms.RadioButton
        Me.rdoState0 = New System.Windows.Forms.RadioButton
        Me.groupGrid = New System.Windows.Forms.GroupBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnCloseSerial = New System.Windows.Forms.Button
        Me.btnOpenSerial = New System.Windows.Forms.Button
        Me.SerialInterface = New System.IO.Ports.SerialPort(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdoStopped)
        Me.GroupBox1.Controls.Add(Me.rdoRunning)
        Me.GroupBox1.Controls.Add(Me.btnToggleState)
        Me.GroupBox1.Enabled = False
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(133, 67)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Start / Stop"
        '
        'rdoStopped
        '
        Me.rdoStopped.AutoSize = True
        Me.rdoStopped.Checked = True
        Me.rdoStopped.Enabled = False
        Me.rdoStopped.Location = New System.Drawing.Point(62, 42)
        Me.rdoStopped.Name = "rdoStopped"
        Me.rdoStopped.Size = New System.Drawing.Size(65, 17)
        Me.rdoStopped.TabIndex = 2
        Me.rdoStopped.TabStop = True
        Me.rdoStopped.Text = "Stopped"
        Me.rdoStopped.UseVisualStyleBackColor = True
        '
        'rdoRunning
        '
        Me.rdoRunning.AutoSize = True
        Me.rdoRunning.Enabled = False
        Me.rdoRunning.Location = New System.Drawing.Point(62, 19)
        Me.rdoRunning.Name = "rdoRunning"
        Me.rdoRunning.Size = New System.Drawing.Size(65, 17)
        Me.rdoRunning.TabIndex = 1
        Me.rdoRunning.Text = "Running"
        Me.rdoRunning.UseVisualStyleBackColor = True
        '
        'btnToggleState
        '
        Me.btnToggleState.Location = New System.Drawing.Point(6, 19)
        Me.btnToggleState.Name = "btnToggleState"
        Me.btnToggleState.Size = New System.Drawing.Size(50, 40)
        Me.btnToggleState.TabIndex = 0
        Me.btnToggleState.Text = "Toggle"
        Me.btnToggleState.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdoQuad4)
        Me.GroupBox2.Controls.Add(Me.rdoQuad3)
        Me.GroupBox2.Controls.Add(Me.rdoQuad2)
        Me.GroupBox2.Controls.Add(Me.rdoQuad1)
        Me.GroupBox2.Enabled = False
        Me.GroupBox2.Location = New System.Drawing.Point(151, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(175, 67)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Quadrant"
        '
        'rdoQuad4
        '
        Me.rdoQuad4.AutoSize = True
        Me.rdoQuad4.Location = New System.Drawing.Point(90, 42)
        Me.rdoQuad4.Name = "rdoQuad4"
        Me.rdoQuad4.Size = New System.Drawing.Size(78, 17)
        Me.rdoQuad4.TabIndex = 3
        Me.rdoQuad4.Text = "Quadrant 4"
        Me.rdoQuad4.UseVisualStyleBackColor = True
        '
        'rdoQuad3
        '
        Me.rdoQuad3.AutoSize = True
        Me.rdoQuad3.Location = New System.Drawing.Point(6, 42)
        Me.rdoQuad3.Name = "rdoQuad3"
        Me.rdoQuad3.Size = New System.Drawing.Size(78, 17)
        Me.rdoQuad3.TabIndex = 2
        Me.rdoQuad3.Text = "Quadrant 3"
        Me.rdoQuad3.UseVisualStyleBackColor = True
        '
        'rdoQuad2
        '
        Me.rdoQuad2.AutoSize = True
        Me.rdoQuad2.Location = New System.Drawing.Point(90, 19)
        Me.rdoQuad2.Name = "rdoQuad2"
        Me.rdoQuad2.Size = New System.Drawing.Size(78, 17)
        Me.rdoQuad2.TabIndex = 1
        Me.rdoQuad2.Text = "Quadrant 2"
        Me.rdoQuad2.UseVisualStyleBackColor = True
        '
        'rdoQuad1
        '
        Me.rdoQuad1.AutoSize = True
        Me.rdoQuad1.Checked = True
        Me.rdoQuad1.Location = New System.Drawing.Point(6, 19)
        Me.rdoQuad1.Name = "rdoQuad1"
        Me.rdoQuad1.Size = New System.Drawing.Size(78, 17)
        Me.rdoQuad1.TabIndex = 0
        Me.rdoQuad1.TabStop = True
        Me.rdoQuad1.Text = "Quadrant 1"
        Me.rdoQuad1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rdoState8)
        Me.GroupBox3.Controls.Add(Me.rdoState7)
        Me.GroupBox3.Controls.Add(Me.rdoState6)
        Me.GroupBox3.Controls.Add(Me.rdoState5)
        Me.GroupBox3.Controls.Add(Me.rdoState4)
        Me.GroupBox3.Controls.Add(Me.rdoState3)
        Me.GroupBox3.Controls.Add(Me.rdoState2)
        Me.GroupBox3.Controls.Add(Me.rdoState1)
        Me.GroupBox3.Controls.Add(Me.rdoState0)
        Me.GroupBox3.Enabled = False
        Me.GroupBox3.Location = New System.Drawing.Point(332, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(266, 97)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Cell state"
        '
        'rdoState8
        '
        Me.rdoState8.AutoSize = True
        Me.rdoState8.Location = New System.Drawing.Point(201, 65)
        Me.rdoState8.Name = "rdoState8"
        Me.rdoState8.Size = New System.Drawing.Size(59, 17)
        Me.rdoState8.TabIndex = 8
        Me.rdoState8.Text = "State 8"
        Me.rdoState8.UseVisualStyleBackColor = True
        '
        'rdoState7
        '
        Me.rdoState7.AutoSize = True
        Me.rdoState7.Location = New System.Drawing.Point(136, 65)
        Me.rdoState7.Name = "rdoState7"
        Me.rdoState7.Size = New System.Drawing.Size(59, 17)
        Me.rdoState7.TabIndex = 7
        Me.rdoState7.Text = "State 7"
        Me.rdoState7.UseVisualStyleBackColor = True
        '
        'rdoState6
        '
        Me.rdoState6.AutoSize = True
        Me.rdoState6.Location = New System.Drawing.Point(71, 65)
        Me.rdoState6.Name = "rdoState6"
        Me.rdoState6.Size = New System.Drawing.Size(59, 17)
        Me.rdoState6.TabIndex = 6
        Me.rdoState6.Text = "State 6"
        Me.rdoState6.UseVisualStyleBackColor = True
        '
        'rdoState5
        '
        Me.rdoState5.AutoSize = True
        Me.rdoState5.Location = New System.Drawing.Point(6, 65)
        Me.rdoState5.Name = "rdoState5"
        Me.rdoState5.Size = New System.Drawing.Size(59, 17)
        Me.rdoState5.TabIndex = 5
        Me.rdoState5.Text = "State 5"
        Me.rdoState5.UseVisualStyleBackColor = True
        '
        'rdoState4
        '
        Me.rdoState4.AutoSize = True
        Me.rdoState4.Location = New System.Drawing.Point(201, 42)
        Me.rdoState4.Name = "rdoState4"
        Me.rdoState4.Size = New System.Drawing.Size(59, 17)
        Me.rdoState4.TabIndex = 4
        Me.rdoState4.Text = "State 4"
        Me.rdoState4.UseVisualStyleBackColor = True
        '
        'rdoState3
        '
        Me.rdoState3.AutoSize = True
        Me.rdoState3.Location = New System.Drawing.Point(136, 42)
        Me.rdoState3.Name = "rdoState3"
        Me.rdoState3.Size = New System.Drawing.Size(59, 17)
        Me.rdoState3.TabIndex = 3
        Me.rdoState3.Text = "State 3"
        Me.rdoState3.UseVisualStyleBackColor = True
        '
        'rdoState2
        '
        Me.rdoState2.AutoSize = True
        Me.rdoState2.Location = New System.Drawing.Point(71, 42)
        Me.rdoState2.Name = "rdoState2"
        Me.rdoState2.Size = New System.Drawing.Size(59, 17)
        Me.rdoState2.TabIndex = 2
        Me.rdoState2.Text = "State 2"
        Me.rdoState2.UseVisualStyleBackColor = True
        '
        'rdoState1
        '
        Me.rdoState1.AutoSize = True
        Me.rdoState1.Location = New System.Drawing.Point(6, 42)
        Me.rdoState1.Name = "rdoState1"
        Me.rdoState1.Size = New System.Drawing.Size(59, 17)
        Me.rdoState1.TabIndex = 1
        Me.rdoState1.Text = "State 1"
        Me.rdoState1.UseVisualStyleBackColor = True
        '
        'rdoState0
        '
        Me.rdoState0.AutoSize = True
        Me.rdoState0.Checked = True
        Me.rdoState0.Location = New System.Drawing.Point(6, 19)
        Me.rdoState0.Name = "rdoState0"
        Me.rdoState0.Size = New System.Drawing.Size(94, 17)
        Me.rdoState0.TabIndex = 0
        Me.rdoState0.TabStop = True
        Me.rdoState0.Text = "State 0 (erase)"
        Me.rdoState0.UseVisualStyleBackColor = True
        '
        'groupGrid
        '
        Me.groupGrid.Enabled = False
        Me.groupGrid.Location = New System.Drawing.Point(12, 85)
        Me.groupGrid.Name = "groupGrid"
        Me.groupGrid.Size = New System.Drawing.Size(314, 324)
        Me.groupGrid.TabIndex = 3
        Me.groupGrid.TabStop = False
        Me.groupGrid.Text = "Cells"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ComboBox1)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.btnCloseSerial)
        Me.GroupBox4.Controls.Add(Me.btnOpenSerial)
        Me.GroupBox4.Location = New System.Drawing.Point(332, 115)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(266, 48)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Serial Port"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(38, 19)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(71, 21)
        Me.ComboBox1.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Port"
        '
        'btnCloseSerial
        '
        Me.btnCloseSerial.Enabled = False
        Me.btnCloseSerial.Location = New System.Drawing.Point(181, 17)
        Me.btnCloseSerial.Name = "btnCloseSerial"
        Me.btnCloseSerial.Size = New System.Drawing.Size(60, 23)
        Me.btnCloseSerial.TabIndex = 1
        Me.btnCloseSerial.Text = "Close"
        Me.btnCloseSerial.UseVisualStyleBackColor = True
        '
        'btnOpenSerial
        '
        Me.btnOpenSerial.Location = New System.Drawing.Point(115, 17)
        Me.btnOpenSerial.Name = "btnOpenSerial"
        Me.btnOpenSerial.Size = New System.Drawing.Size(60, 23)
        Me.btnOpenSerial.TabIndex = 0
        Me.btnOpenSerial.Text = "Open"
        Me.btnOpenSerial.UseVisualStyleBackColor = True
        '
        'SerialInterface
        '
        Me.SerialInterface.BaudRate = 115200
        '
        'frmControlSurface
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(612, 424)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.groupGrid)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "frmControlSurface"
        Me.Text = "MondoLife Control Surface"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoStopped As System.Windows.Forms.RadioButton
    Friend WithEvents rdoRunning As System.Windows.Forms.RadioButton
    Friend WithEvents btnToggleState As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoQuad4 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoQuad3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoQuad2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoQuad1 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents rdoState3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState1 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState0 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState7 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState6 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState5 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoState4 As System.Windows.Forms.RadioButton
    Friend WithEvents groupGrid As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCloseSerial As System.Windows.Forms.Button
    Friend WithEvents btnOpenSerial As System.Windows.Forms.Button
    Friend WithEvents SerialInterface As System.IO.Ports.SerialPort
    Friend WithEvents rdoState8 As System.Windows.Forms.RadioButton

End Class
