﻿Public Class frmControlSurface

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim newButton As Button
        Dim i, j As Integer

        For i = 1 To 8
            For j = 1 To 8
                newButton = New Button
                newButton.Left = groupGrid.Left + ((j - 1) * 35) + 5
                newButton.Top = ((i - 1) * 35) + 25
                newButton.Height = 30
                newButton.Width = 30
                newButton.Name = "GridButton_" + i.ToString.Trim + "_" + j.ToString.Trim

                AddHandler newButton.Click, AddressOf Pixel_ClickHandler

                groupGrid.Controls.Add(newButton)
            Next
        Next


        ComboBox1.Items.Clear()
        For Each serialPort In My.Computer.Ports.SerialPortNames
            ComboBox1.Items.Add(serialPort)
        Next
    End Sub

    Private Sub Pixel_ClickHandler(ByVal Sender As Object, ByVal e As EventArgs)
        Dim arrayData As String()
        Dim x, y As Integer
        Dim transmitBuffer(7) As Byte
        Dim xoffset, yoffset As Integer
        Dim nextState As Integer
        arrayData = Split(Sender.name, "_")

        y = Val(arrayData(1))
        x = Val(arrayData(2))

        'MsgBox("Clicked in x: " + x.ToString + ", y: " + y.ToString)

        'First find the quadrant, get our offsets that way
        If rdoQuad1.Checked = True Then
            xoffset = 0
            yoffset = 0
        ElseIf rdoQuad2.Checked = True Then
            xoffset = 8
            yoffset = 0
        ElseIf rdoQuad3.Checked = True Then
            xoffset = 0
            yoffset = 8
        ElseIf rdoQuad4.Checked = True Then
            xoffset = 8
            yoffset = 8
        End If

        x = x + xoffset
        y = y + yoffset

        'Now find the state we move to
        If rdoState0.Checked = True Then
            nextState = 0
        ElseIf rdoState1.Checked = True Then
            nextState = 1
        ElseIf rdoState2.Checked = True Then
            nextState = 2
        ElseIf rdoState3.Checked = True Then
            nextState = 3
        ElseIf rdoState4.Checked = True Then
            nextState = 4
        ElseIf rdoState5.Checked = True Then
            nextState = 5
        ElseIf rdoState6.Checked = True Then
            nextState = 6
        ElseIf rdoState7.Checked = True Then
            nextState = 7
        ElseIf rdoState8.Checked = True Then
            nextState = 8
        End If

        'prepare the transmit buffer
        transmitBuffer(0) = Asc("!")
        transmitBuffer(1) = Asc("!")
        transmitBuffer(2) = Asc("!")
        transmitBuffer(3) = Asc("4")
        transmitBuffer(4) = x
        transmitBuffer(5) = y
        transmitBuffer(6) = nextState

        SerialInterface.Write(transmitBuffer, 0, 7)
    End Sub

    Private Sub RadioButton5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdoState0.CheckedChanged

    End Sub

    Private Sub btnOpenSerial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenSerial.Click
        SerialInterface.PortName = ComboBox1.Text
        SerialInterface.Open()
        btnOpenSerial.Enabled = False
        ComboBox1.Enabled = False
        btnCloseSerial.Enabled = True
        GroupBox1.Enabled = True
        GroupBox2.Enabled = True
        GroupBox3.Enabled = True
        groupGrid.Enabled = True
    End Sub

    Private Sub btnCloseSerial_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCloseSerial.Click
        SerialInterface.Close()
        btnOpenSerial.Enabled = True
        ComboBox1.Enabled = True
        btnCloseSerial.Enabled = False
        GroupBox1.Enabled = False
        GroupBox2.Enabled = False
        GroupBox3.Enabled = False
        groupGrid.Enabled = False
    End Sub

    Private Sub btnToggleState_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnToggleState.Click
        If rdoRunning.Checked = True Then
            ' send stop command
            SerialInterface.Write("!!!0")
            rdoRunning.Checked = False
            rdoStopped.Checked = True
        Else
            SerialInterface.Write("!!!1")
            rdoRunning.Checked = True
            rdoStopped.Checked = False
        End If
    End Sub

    Private Sub SerialInterface_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialInterface.DataReceived
        Dim d As Byte

        d = SerialInterface.ReadByte

    End Sub
End Class
