﻿Public Class Form1

    Private Quadrant1Red(64) As Byte
    Private Quadrant1Green(64) As Byte
    Private Quadrant1Blue(64) As Byte

    Private Quadrant2Red(64) As Byte
    Private Quadrant2Green(64) As Byte
    Private Quadrant2Blue(64) As Byte

    Private Quadrant3Red(64) As Byte
    Private Quadrant3Green(64) As Byte
    Private Quadrant3Blue(64) As Byte

    Private Quadrant4Red(64) As Byte
    Private Quadrant4Green(64) As Byte
    Private Quadrant4Blue(64) As Byte

    Private IncomingCommand As Byte
    Private IncomingX As Byte
    Private IncomingY As Byte
    Private IncomingBlue As Byte
    Private IncomingGreen As Byte
    Private IncomingRed As Byte
    Private IncomingBlueArray(64) As Byte
    Private IncomingGreenArray(64) As Byte
    Private IncomingRedArray(64) As Byte
    Private IncomingCount As Integer
    Private IncomingAddress As Integer

    Enum LEDMatrixReceiveState As Integer
        Waiting = 0
        AddressCount
        Address
        DataCount
        Command
        ActiveLED
        OneRed
        OneGreen
        OneBlue
        Red
        Green
        Blue
    End Enum

    Private ReceiveState As LEDMatrixReceiveState = LEDMatrixReceiveState.Waiting

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim j As Integer
        Dim pic As PictureBox

        For i = 0 To 15
            For j = 0 To 15
                pic = New PictureBox
                pic.BackColor = Color.Black
                pic.Height = 15
                pic.Width = 15
                pic.Top = (j * 15) + 20
                pic.Left = (i * 15) + 10
                pic.Name = "Pixel_" + Trim(i.ToString) + "_" + Trim(j.ToString)
                GroupBox2.Controls.Add(pic)
            Next
        Next

        cboSerialPorts.Items.Clear()
        For Each serialPort In My.Computer.Ports.SerialPortNames
            cboSerialPorts.Items.Add(serialPort)
        Next

        For i = 0 To 63
            Quadrant1Blue(i) = 0
            Quadrant1Green(i) = 0
            Quadrant1Red(i) = 0
            Quadrant2Blue(i) = 0
            Quadrant2Green(i) = 0
            Quadrant2Red(i) = 0
            Quadrant3Blue(i) = 0
            Quadrant3Green(i) = 0
            Quadrant3Red(i) = 0
            Quadrant4Blue(i) = 0
            Quadrant4Green(i) = 0
            Quadrant4Red(i) = 0
        Next

        RedrawDisplay()
    End Sub

    Private Sub cmdOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOpen.Click
        SerialInterface.PortName = cboSerialPorts.Text
        SerialInterface.Open()
        cboSerialPorts.Enabled = False
        cmdClose.Enabled = True
        cmdOpen.Enabled = False
    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        SerialInterface.Close()
        cboSerialPorts.Enabled = True
        cmdOpen.Enabled = True
        cmdClose.Enabled = False
    End Sub

    Private Sub RedrawDisplay()
        Dim i As Integer
        Dim j As Integer
        Dim currentIndex As Integer
        Dim x, y As Integer


        'quadrant 1
        For i = 0 To 7
            For j = 0 To 7
                currentIndex = (i * 8) + j
                x = j
                y = i
                GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(Quadrant1Red(currentIndex), Quadrant1Green(currentIndex), Quadrant1Blue(currentIndex))
            Next
        Next

        'quadrant 2
        For i = 0 To 7
            For j = 0 To 7
                currentIndex = (i * 8) + j
                x = j + 8
                y = i
                GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(Quadrant2Red(currentIndex), Quadrant2Green(currentIndex), Quadrant2Blue(currentIndex))
            Next
        Next

        'quadrant 3
        For i = 0 To 7
            For j = 0 To 7
                currentIndex = (i * 8) + j
                x = j
                y = i + 8
                GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(Quadrant3Red(currentIndex), Quadrant3Green(currentIndex), Quadrant3Blue(currentIndex))
            Next
        Next

        'quadrant 4
        For i = 0 To 7
            For j = 0 To 7
                currentIndex = (i * 8) + j
                x = j + 8
                y = i + 8
                GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(Quadrant4Red(currentIndex), Quadrant4Green(currentIndex), Quadrant4Blue(currentIndex))
            Next
        Next
    End Sub

    Private Sub SerialInterface_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialInterface.DataReceived
        Dim ReadByte As Byte
        Dim x, y As Integer

        While SerialInterface.BytesToRead > 0
            ReadByte = SerialInterface.ReadByte

            Select Case ReceiveState
                Case LEDMatrixReceiveState.Waiting
                    If ReadByte = Asc("A") Then
                        ReceiveState = LEDMatrixReceiveState.AddressCount
                    ElseIf ReadByte = Asc("D") Then
                        ReceiveState = LEDMatrixReceiveState.DataCount
                    Else
                        ReceiveState = LEDMatrixReceiveState.Waiting
                    End If
                Case LEDMatrixReceiveState.AddressCount
                    ReceiveState = LEDMatrixReceiveState.Address
                Case LEDMatrixReceiveState.DataCount
                    ReceiveState = LEDMatrixReceiveState.Command
                Case LEDMatrixReceiveState.Address
                    IncomingAddress = ReadByte
                    ReceiveState = LEDMatrixReceiveState.Waiting
                Case LEDMatrixReceiveState.Command
                    If ReadByte = 1 Then
                        IncomingCount = 0
                        ReceiveState = LEDMatrixReceiveState.Red
                    ElseIf ReadByte = 2 Then
                        ReceiveState = LEDMatrixReceiveState.ActiveLED
                    Else
                        ReceiveState = LEDMatrixReceiveState.Waiting
                    End If
                Case LEDMatrixReceiveState.ActiveLED
                    IncomingCommand = ReadByte
                    ReceiveState = LEDMatrixReceiveState.OneRed
                Case LEDMatrixReceiveState.OneRed
                    IncomingRed = ReadByte
                    ReceiveState = LEDMatrixReceiveState.OneGreen
                Case LEDMatrixReceiveState.OneGreen
                    IncomingGreen = ReadByte
                    ReceiveState = LEDMatrixReceiveState.OneBlue
                Case LEDMatrixReceiveState.OneBlue
                    IncomingBlue = ReadByte
                    ReceiveState = LEDMatrixReceiveState.Waiting

                    x = IncomingCommand Mod 8
                    y = (IncomingCommand - x) / 8

                    If IncomingAddress = 0 Then
                        'quadrant one
                        Quadrant1Red(IncomingCommand) = IncomingRed
                        Quadrant1Green(IncomingCommand) = IncomingGreen
                        Quadrant1Blue(IncomingCommand) = IncomingBlue

                        GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(IncomingRed, IncomingGreen, IncomingBlue)
                    ElseIf IncomingAddress = 1 Then
                        'quadrant two
                        Quadrant2Red(IncomingCommand) = IncomingRed
                        Quadrant2Green(IncomingCommand) = IncomingGreen
                        Quadrant2Blue(IncomingCommand) = IncomingBlue

                        x = x + 8
                        GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(IncomingRed, IncomingGreen, IncomingBlue)
                    ElseIf IncomingAddress = 2 Then
                        'quadrant three
                        Quadrant3Red(IncomingCommand) = IncomingRed
                        Quadrant3Green(IncomingCommand) = IncomingGreen
                        Quadrant3Blue(IncomingCommand) = IncomingBlue

                        y = y + 8
                        GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(IncomingRed, IncomingGreen, IncomingBlue)
                    ElseIf IncomingAddress = 3 Then
                        'quadrant two
                        Quadrant4Red(IncomingCommand) = IncomingRed
                        Quadrant4Green(IncomingCommand) = IncomingGreen
                        Quadrant4Blue(IncomingCommand) = IncomingBlue

                        x = x + 8
                        y = y + 8
                        GroupBox2.Controls("Pixel_" + x.ToString.Trim + "_" + y.ToString.Trim).BackColor = System.Drawing.Color.FromArgb(IncomingRed, IncomingGreen, IncomingBlue)
                    End If
                Case LEDMatrixReceiveState.Red
                    IncomingRedArray(IncomingCount) = ReadByte
                    ReceiveState = LEDMatrixReceiveState.Green
                Case LEDMatrixReceiveState.Green
                    IncomingGreenArray(IncomingCount) = ReadByte
                    ReceiveState = LEDMatrixReceiveState.Blue
                Case LEDMatrixReceiveState.Blue
                    IncomingBlueArray(IncomingCount) = ReadByte
                    IncomingCount = IncomingCount + 1
                    If IncomingCount = 64 Then
                        IncomingCount = 0
                        ReceiveState = LEDMatrixReceiveState.Waiting
                        If IncomingAddress = 0 Then
                            For i = 0 To 63
                                Quadrant1Red(i) = IncomingRedArray(i)
                                Quadrant1Green(i) = IncomingGreenArray(i)
                                Quadrant1Blue(i) = IncomingBlueArray(i)
                            Next
                        ElseIf IncomingAddress = 1 Then
                            For i = 0 To 63
                                Quadrant2Red(i) = IncomingRedArray(i)
                                Quadrant2Green(i) = IncomingGreenArray(i)
                                Quadrant2Blue(i) = IncomingBlueArray(i)
                            Next
                        ElseIf IncomingAddress = 2 Then
                            For i = 0 To 63
                                Quadrant3Red(i) = IncomingRedArray(i)
                                Quadrant3Green(i) = IncomingGreenArray(i)
                                Quadrant3Blue(i) = IncomingBlueArray(i)
                            Next
                        ElseIf IncomingAddress = 3 Then
                            For i = 0 To 63
                                Quadrant4Red(i) = IncomingRedArray(i)
                                Quadrant4Green(i) = IncomingGreenArray(i)
                                Quadrant4Blue(i) = IncomingBlueArray(i)
                            Next
                        End If
                        RedrawDisplay()
                    Else
                        ReceiveState = LEDMatrixReceiveState.Red
                    End If
                Case Else
                    ReceiveState = LEDMatrixReceiveState.Waiting
            End Select
        End While
    End Sub
End Class
