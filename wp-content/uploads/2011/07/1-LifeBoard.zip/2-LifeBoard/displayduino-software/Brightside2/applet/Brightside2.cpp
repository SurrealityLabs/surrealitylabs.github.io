#include <MatrixNetBridge.h>
//#include <MatrixNet.h>

#include <Life.h>

#define STATE_WAITING 0
#define STATE_HEADER1 1
#define STATE_HEADER2 2
#define STATE_COMMAND 3
#define STATE_SETCELL_X 4
#define STATE_SETCELL_Y 5
#define STATE_SETCELL_TYPE 6

#define PERIOD_MILLIS 1000

#include "WProgram.h"
void setup();
void loop();
void IterateLife();
void UpdateDisplay();
unsigned char receiveState = STATE_WAITING;
int setX = 0;
int setY = 0;

unsigned char MapStateToRed[]   = {0, 255,   0,   0, 255, 255,   0, 255, 255};
unsigned char MapStateToBlue[]  = {0,   0,   0, 255, 255,   0, 255, 168, 255};
unsigned char MapStateToGreen[] = {0,   0, 255,   0,   0, 255, 255,   0, 255};

unsigned char runningMode = 0;

int lastRun = 0;

//int LifeGrid[16][16];
life lifeGame;

MatrixNetBridge myMatrix;
//MatrixNet myMatrix;

unsigned char i = 0;
unsigned char j = 0;

void setup()
{
  myMatrix.begin();
  Serial.begin(115200);
  pinMode(0, OUTPUT);
  lastRun = millis();

  UpdateDisplay();
}

void loop()
{
  int receivedByte = 0;
  int thisRun = 0;
  
  if(runningMode) {
    thisRun = millis();
    if(thisRun > (lastRun + PERIOD_MILLIS)) {
      lastRun = thisRun;
      IterateLife();
      UpdateDisplay();
    }
  }

  while (Serial.available() > 0) {
    // read the incoming byte:
    receivedByte = Serial.read();
    Serial.print(receivedByte, BYTE);
    switch(receiveState) {
      case STATE_WAITING:
        if(receivedByte == '!') {
          receiveState = STATE_HEADER1;
        } else {
          receiveState = STATE_WAITING;
        }
        break;
      case STATE_HEADER1:
        if(receivedByte == '!') {
          receiveState = STATE_HEADER2;
        } else {
          receiveState = STATE_WAITING;
        }
        break;
      case STATE_HEADER2:
        if(receivedByte == '!') {
          receiveState = STATE_COMMAND;
        } else {
          receiveState = STATE_WAITING;
        }
        break;
      case STATE_COMMAND:
        if(receivedByte == '0') {
          // stop command goes here
          runningMode = 0;
          receiveState = STATE_WAITING;
        } else if(receivedByte == '1') {
          // start command goes here
          runningMode = 1;
          receiveState = STATE_WAITING;
        } else if(receivedByte == '2') {
          // next frame command goes here
          IterateLife();
          UpdateDisplay();
        } else if(receivedByte == '3') {   
          // clear command goes here
          unsigned char i;
          for(i=0;i<16;i++) {
            lifeGame.grid[0][i] = 0;
            lifeGame.grid[1][i] = 0;
            lifeGame.grid[2][i] = 0;
            lifeGame.grid[3][i] = 0;
            lifeGame.grid[4][i] = 0;
            lifeGame.grid[5][i] = 0;
            lifeGame.grid[6][i] = 0;
            lifeGame.grid[7][i] = 0;
            lifeGame.grid[8][i] = 0;
            lifeGame.grid[9][i] = 0;
            lifeGame.grid[10][i] = 0;
            lifeGame.grid[11][i] = 0;
            lifeGame.grid[12][i] = 0;
            lifeGame.grid[13][i] = 0;
            lifeGame.grid[14][i] = 0;
            lifeGame.grid[15][i] = 0;
          }
          receiveState = STATE_WAITING;
        } else if(receivedByte == '4') {
          // set single pixel
          receiveState = STATE_SETCELL_X;
        } else if(receivedByte == '5') {
          // set array
          // add this code later
          receiveState = STATE_WAITING;
        } else {
          receiveState = STATE_WAITING;
        }
        break;
      case STATE_SETCELL_X:
        setX = receivedByte - 1;
        receiveState = STATE_SETCELL_Y;
        //Serial.println("Received X");
        break;
      case STATE_SETCELL_Y:
        setY = receivedByte - 1;
        receiveState = STATE_SETCELL_TYPE;
        digitalWrite(0, HIGH);
        delay(100);
        digitalWrite(0, LOW);
        //Serial.println("Received Y");
        break;
      case STATE_SETCELL_TYPE:
        if(receivedByte > 8) receivedByte = 0;
        if(setX > 15) setX = 15;
        if(setX < 0) setX = 0;
        if(setY > 15) setY = 15;
        if(setY < 0) setY = 0;

        //Serial.flush();
        lifeGame.grid[setX][setY] = receivedByte;
        //Serial.println("Received type, setting.");
        // update the display grid
        UpdateDisplay();
        receiveState = STATE_WAITING;
        break;
      default:
        receiveState = STATE_WAITING;
        break;
    }
  }
}

void IterateLife() {
  lifeGame.next();
  return;
}

void UpdateDisplay() {
  unsigned char Red[64], Green[64], Blue[64];
  
  unsigned char j, k, a, b;
  
  // do first quadrant, uh, first
  for(j=0;j<8;j++) {
    for(k=0;k<8;k++) {
      a = k;
      b = j;
      Red[(j*8)+k] = MapStateToRed[lifeGame.grid[a][b]];
      Blue[(j*8)+k] = MapStateToBlue[lifeGame.grid[a][b]];
      Green[(j*8)+k] = MapStateToGreen[lifeGame.grid[a][b]];
    }
  }
  
  myMatrix.changeLEDBoard(0, Red, Green, Blue);
  
  // do second quadrant
  for(j=0;j<8;j++) {
    for(k=0;k<8;k++) {
      a = k + 8;
      b = j;
      Red[(j*8)+k] = MapStateToRed[lifeGame.grid[a][b]];
      Blue[(j*8)+k] = MapStateToBlue[lifeGame.grid[a][b]];
      Green[(j*8)+k] = MapStateToGreen[lifeGame.grid[a][b]];
    }
  }
  
  myMatrix.changeLEDBoard(1, Red, Green, Blue);
  
  // do third quadrant
  for(j=0;j<8;j++) {
    for(k=0;k<8;k++) {
      a = k;
      b = j + 8;
      Red[(j*8)+k] = MapStateToRed[lifeGame.grid[a][b]];
      Blue[(j*8)+k] = MapStateToBlue[lifeGame.grid[a][b]];
      Green[(j*8)+k] = MapStateToGreen[lifeGame.grid[a][b]];
    }
  }
  
  myMatrix.changeLEDBoard(2, Red, Green, Blue);
  
  // do fourth quadrant
  for(j=0;j<8;j++) {
    for(k=0;k<8;k++) {
      a = k + 8;
      b = j + 8;
      Red[(j*8)+k] = MapStateToRed[lifeGame.grid[a][b]];
      Blue[(j*8)+k] = MapStateToBlue[lifeGame.grid[a][b]];
      Green[(j*8)+k] = MapStateToGreen[lifeGame.grid[a][b]];
    }
  }
  
  myMatrix.changeLEDBoard(3, Red, Green, Blue);
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

