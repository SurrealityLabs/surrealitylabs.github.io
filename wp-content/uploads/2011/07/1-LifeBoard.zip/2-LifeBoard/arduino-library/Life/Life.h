/*
 *  Life.h
 *
 *  Created by Rudie Shahinian on 04/09/10.
 *  Copyright 2010 BrightSide. All rights reserved.
 *
 */

#ifndef _Life_h_
#define _Life_h_

#define GRIDSIZE 16
#define NUM_OF_TEAMS 2
#define NUM_OF_STATES 8

class life {
public:
	life();
	~life();
	void clearGrid();
	void next();
	void outputGrid();
	void setCell(int, int, int);
	int getCell(int, int);
	int grid[GRIDSIZE][GRIDSIZE];
	
private:
	
	int team1 [NUM_OF_STATES/2];
	int team2[NUM_OF_STATES/2];
	void getCellNeighbours(int*, int,int);
	int isInTeam(int);
	int randState(int, int, int);
};

#endif
