/*
 *  Created by Rudie Shahinian on 04/09/10.
 *  Copyright 2010 BrightSide. All rights reserved.
 *
 */
#include <Life.h>
#include "WProgram.h"
void setup();
void loop();
life lifegame;
int x = 0;
int y = 0;
int cycle = 0;
void setup()   {                
   	
  Serial.begin(9600);
  //x,y,state - two teams with 8states, team1: 1,2,3,4 team2: 5,6,7,8
  lifegame.setCell(3, 5 ,1 );
  lifegame.setCell(3, 6 ,3 );
  lifegame.setCell(3, 7 ,4 );
  lifegame.setCell(3, 8 ,2 );
  lifegame.setCell(3, 9 ,1 );
  lifegame.setCell(4, 3 ,6 );
  lifegame.setCell(5, 3 ,5 );
  lifegame.setCell(6, 3 ,7 );
  lifegame.setCell(7, 3 ,8 );
  lifegame.setCell(8, 3 ,6 );
}


void loop() {
  cycle++;
  
  for (y=15; y>=0; y--) {
    for (x=0; x<16; x++) {
      Serial.print(lifegame.grid[x][y]);
    }
    Serial.println("");
  }
  Serial.println("");
  Serial.print("cycle: ");
  Serial.println(cycle);	
  delay(500);
  lifegame.next();
    
}


int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

