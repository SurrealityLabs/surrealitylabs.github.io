#include <htc.h>
#include <math.h>

#define ON 1
#define OFF 0

#define _XTAL_FREQ 20000000

#define LED_DELAY 0
#define CLOCK_DELAY 0
#define LATCH_DELAY 0

#define YELLOW_CLOCK	RC7
#define YELLOW_LOAD		RC6
#define YELLOW_DATA		RC5
#define YELLOW_BASE_0	RC4
#define YELLOW_BASE_1	RC3
#define YELLOW_BASE_2	RC2
#define YELLOW_BASE_3	RC1

#define RED_CLOCK		RA2
#define RED_LOAD		RA1
#define RED_DATA		RA3
#define RED_BASE_0		RA0
#define RED_BASE_1		RB0
#define RED_BASE_2		RB1


#define REDOFFSET		4


/*
#define YELLOW_CLOCK	PORTC.RC7
#define YELLOW_LOAD		RC6
#define YELLOW_DATA		RC5
#define YELLOW_BASE_0	RC4
#define YELLOW_BASE_1	RC3
#define YELLOW_BASE_2	RC2
#define YELLOW_BASE_3	RC1

#define RED_CLOCK		RA3
#define RED_LOAD		RA2
#define RED_DATA		RA1
#define RED_BASE_0		RA0
#define RED_BASE_1		RB0
#define RED_BASE_2		RB1

*/

volatile char LEDS[7];



void led_update();
void setbit(char bitnum,char val);
char readbit(char bitnum);
void setyellowLED(char bitnum,char val);




void main(void)
	{

	char i,j,k,m,t,l,p;
	//char ll,pp;
	int state=1;
	char rotate=0;
	char redarray[]={0,0,0,0,0,0,0};
	char resetRedarray[]={32,35,38,42,45,48,51};
	char redcounter=0;
	
	TRISA=0x00;
	TRISB=0b10000000;
	TRISC=0x00;
	
	PORTA=0x00;
	PORTB=0x00;
	PORTC=0x00;
	
	
		PORTA=0x0F;
		PORTB=0xFF;
		PORTC=0xFF;
		_delay(100000);
		
	
		PORTA=0x00;
		PORTB=0x00;
		PORTC=0x00;
		

		//fun test program
		//set the 3rd light on
		

			
		
		j=0;
		k=3;
		LEDS[0]=0x00;
		LEDS[1]=0x00;
		LEDS[2]=0x00;
		LEDS[3]=0x00;
		LEDS[4]=0x00;
		LEDS[5]=0x00;
		LEDS[6]=0x00;
	
//		ll=0;
//		pp=0;

//setup the timer

	TMR0=0;
	OPTION=T0SE|PS2|PS1|PS0;
	
	/*T0CS=0;
	T0SE=1;
	PSA=0;
	PS2=0;
	PS1=1;
	PS0=0;
*/

rotate=0;
	while(1)
	{	
	
	if(TMR0>0xEA)
	{
		setbit(rotate,1);
		
		if (rotate>0)
		{
			setbit(rotate-1,0);
		}else{
			setbit(27,0);
			
		}	
		rotate++;
			
		if(rotate==28)
		{
			rotate=0;
		}	
		
		if (redcounter>5)
		{
			for (i=0;i<7;i++)
			{
				setbit(resetRedarray[i]+redarray[i],1);
				redarray[i]++;
				
				if((redarray[i]>4)&&(i!=2))
				{redarray[i]=0;
				
				setbit(resetRedarray[i],0);			
				setbit(resetRedarray[i]+1,0);
				setbit(resetRedarray[i]+2,0);
	
				
				}else if((redarray[i]>4)&&(i==2))
				{redarray[i]=0;
				setbit(resetRedarray[i],0);			
				setbit(resetRedarray[i]+1,0);
				setbit(resetRedarray[i]+2,0);
				setbit(resetRedarray[i]+3,0);
				}
				
			}
			redcounter=0;
		}			
		redcounter++;
		
		TMR0=0;
	}	
	
	//update the leds
	led_update();		
	}
}



//char checkSwich()
//{
//	if (RB7==0)
//	{
//		return(1);			
//	}else{
//		return(0);
//	}
//}

/*int delayTimer(int delay)
{
	int irxx=0;
	for (irxx=0;irxx<delay;irxx++)
		{

			_delay(100);
			if (checkSwich())
			{
				_delay(100);
				if (checkSwich())
				{
					_delay(10000);
					offAll();
					return(1);
				}
			}
	}
	return(0);
}*/
void led_update()
{
	//go through all the leds and update their status
	
	char ir,j;//ir = shift reg val(row), j is transistor (col) 
	char k,l;
	char maxremainder,maxBase,mask;
	char redId=0;
	char yellowId=0;
	char redBase,redShiftpin,yellowBase,yellowShiftpin;
	char remainder;
	
	
	for (maxBase=0;maxBase<4;maxBase++)
	{
		for(remainder=0;remainder<8;remainder++)
		{
			yellowShiftpin=0;
			redShiftpin=0;
			
			mask=(1<<remainder);
			
			if(((LEDS[maxBase]&mask)>>remainder))
			{
				yellowShiftpin=1;
			}
			if(((LEDS[maxBase+REDOFFSET]&mask)>>remainder))
			{
				redShiftpin=1;
			}
			
			for(l=0;l<8;l++)
			{
				if (7-remainder==l)
				{
					YELLOW_DATA=yellowShiftpin;		
				}else{
					YELLOW_DATA=0x00;
				}
				if (7-remainder==l)
				{
					RED_DATA=redShiftpin;		
				}else{
					RED_DATA=0x00;
				}
				
				
				YELLOW_CLOCK=1;
				RED_CLOCK=1;
				_delay(CLOCK_DELAY);
				YELLOW_CLOCK=0;
				RED_CLOCK=0;
				_delay(CLOCK_DELAY);
		
			}//end load data loop
				
				YELLOW_BASE_0=0;
				YELLOW_BASE_1=0;
				YELLOW_BASE_2=0;
				YELLOW_BASE_3=0;
				RED_BASE_0=0;
				RED_BASE_1=0;
				RED_BASE_2=0;
				
				YELLOW_LOAD=1;
				RED_LOAD=1;
				_delay(LATCH_DELAY);
				YELLOW_LOAD=0;
				RED_LOAD=0;
				
				switch(maxBase)
				{
					case 0:
						YELLOW_BASE_0=1;
						RED_BASE_0=1;
						break;
					case 1:
						YELLOW_BASE_1=1;
						RED_BASE_1=1;
						break;
					case 2:
						YELLOW_BASE_2=1;
						RED_BASE_2=1;
						break;
					case 3:
						YELLOW_BASE_3=1;
						//No Red at this value
						break;
					default:
					break;
				}//end base loop
				__delay_ms(LED_DELAY);
		}//end the remainder loop
	}//end the base loop			
}
	
void setyellowLED(char bitnum,char val)
{
	setbit(bitnum,val);
}	

/*
void red_Led(char lick,char led,char onOff)
{
	char irxx,j;//irxx = shift reg val(row), j is transistor (col) 
	char k,l;
	switch(lick)
		{

		case 0:
			switch(led)
			{
				case 0:
					irxx=3;
					j=2;
					break;
				case 1:
					irxx=4;
					j=2;
					break;
				case 2:
					irxx=5;
					j=2;
					break;
				default:
					break;			
			}		
			break;
		case 1:
			switch(led)
			{
				case 0:
					irxx=0;
					j=2;
					break;
				case 1:
					irxx=1;
					j=2;
					break;
				case 2:
					irxx=2;
					j=2;
					break;
				default:
					break;			
			}		
			break;
		case 2:
			switch(led)
			{
				case 0:
					irxx=5;
					j=1;
					break;
				case 1:
					irxx=6;
					j=1;
					break;
				case 2:
					irxx=7;
					j=1;
					break;
				default:
					break;			
			}		
			break;
		case 3:
			switch(led)
			{
				case 0:
					irxx=2;
					j=1;
					break;
				case 1:
					irxx=3;
					j=1;
					break;
				case 2:
					irxx=4;
					j=1;
					break;
				default:
					break;			
			}		
			break;
		case 4:
			switch(led)
			{
				case 0:
					irxx=6;
					j=0;
					break;
				case 1:
					irxx=7;
					j=0;
					break;
				case 2:
					irxx=0;
					j=1;
					break;
				case 3:
					irxx=1;
					j=1;
					break;
				default:
					break;			
			}		
			break;
		case 5:
			switch(led)
			{
				case 0:
					irxx=3;
					j=0;
					break;
				case 1:
					irxx=4;
					j=0;
					break;
				case 2:
					irxx=5;
					j=0;
					break;
				default:
					break;			
			}		
			break;
		case 6:
			switch(led)
			{
				case 0:
					irxx=0;
					j=0;
					break;
				case 1:
					irxx=1;
					j=0;
					break;
				case 2:
					irxx=2;
					j=0;
					break;
				default:
					break;			
			}		
			break;
		default:
			break;
		}
		
			for(l=0;l<8;l++)
				{
					if (7-irxx==l)
					{
						RED_DATA=onOff;
						
					}else{
						RED_DATA=0x00;
					}
					RED_CLOCK=1;
					_delay(CLOCK_DELAY);
					RED_CLOCK=0;
					_delay(CLOCK_DELAY);		
				}
				
				RED_BASE_0=0;
				RED_BASE_1=0;
				RED_BASE_2=0;
				
				//now latch
				RED_LOAD=1;
				_delay(LATCH_DELAY);
				RED_LOAD=0;
				//turn on the base;
				
				switch(j)
				{
					case 0:
						RED_BASE_0=1;
						break;
					case 1:
						RED_BASE_1=1;
						break;
					case 2:
						RED_BASE_2=1;
						break;
					default:
					break;
				}
				//__delay_ms(LED_DELAY);
				
				if(onOff==OFF)
				{
					RED_BASE_0=0;
					RED_BASE_1=0;
					RED_BASE_2=0;	
				}		
}
	
	
	*/


void setbit(char bitnum,char val)
{
	unsigned char arraynum,remainder,mask;
	
	arraynum = bitnum/8;
	remainder = bitnum-(arraynum)*8;
	mask=255-(1<<remainder);

	//do some yellow changeups
	if(arraynum==2){
		arraynum=1;
	}else if(arraynum==1){
		arraynum=2;
	}	


	if (val==1)
	{
		LEDS[arraynum]|=(1<<remainder);
	}else{
		LEDS[arraynum]&=mask;
	}
	
	

}

char readbit(char bitnum)
{
	unsigned char arraynum,remainder,val;
	
	arraynum = bitnum/8;
	remainder = bitnum-(arraynum)*8;
	
	return((LEDS[arraynum]&(1<<remainder))>>remainder);
}


	


		
/*kkk*/
//void setYellowLED(char number, char brightness)
//{
//	char tmp;
//	tmp=number>>2;
//	tmp=tmp<<2;
//	
//	if((number-tmp)>0)	//odd
//	{	//left side
//		tmp=number>>2;
//		LEDS[tmp]&=0x0F;
//		LEDS[tmp]+=brightness<<4;
//	}else{	
//		//right side
//		LEDS[tmp]&=0xF0;
//		LEDS[tmp]+=brightness;
//	}	
//}
//
//char getYellowLeds(char number)
//{
//	char tmp;
//	tmp=number>>2;
//	tmp=tmp<<2;
//	
//	if((number-tmp)>0)	//odd
//	{	//left side
//		tmp=number>>2;
//		return ((LEDS[tmp]&0xF0)>>4);
//		//LEDS[tmp]+=brightness<<4;
//	}else{	
//		//right side
//		return(LEDS[tmp]&=0x0F);
//	}	
//}



	